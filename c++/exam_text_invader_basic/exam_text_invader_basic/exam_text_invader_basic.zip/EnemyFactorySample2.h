#pragma once
#include "EnemyFactory.h"
class CEnemyFactorySample2 :
	public CEnemyFactory
{
public:
	CEnemyFactorySample2();
	~CEnemyFactorySample2();
};

