#pragma once
#include "EnemyFactory.h"

class CEnemyFactorySample1 :
	public CEnemyFactory
{
public:
	CEnemyFactorySample1();
	~CEnemyFactorySample1();

};

