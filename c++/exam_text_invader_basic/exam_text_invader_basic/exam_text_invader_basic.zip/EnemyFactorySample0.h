#pragma once
#include "EnemyFactory.h"
class CEnemyFactorySample0 :
	public CEnemyFactory
{
public:
	CEnemyFactorySample0();
	~CEnemyFactorySample0();
};

