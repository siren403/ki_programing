// exam_text_invader_basic.cpp : Defines the entry point for the console application.
//
#include "stdafx.h"
#include "GameManager.h"


int main()
{
	CGameManager mGM;
	
	mGM.Play();

    return 0;
}

