#pragma once

//------------------------------------ Screen
#define WIDTH 80
#define HEIGHT 24

//------------------------------------ Bullet
#define ACTOR_BULLET_COUNT 10

#define ENEMY_BULLET_COUNT 5



//------------------------------------ EnemyCount
//#define TOTAL_ENEMY_COUNT 1
//#define TOTAL_BOSS_ENEMY_COUNT 2


#define ENEMY_BULLETS_SET_COUNT 3
