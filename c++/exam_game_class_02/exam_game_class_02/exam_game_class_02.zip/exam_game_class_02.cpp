#include "stdafx.h"
#include <iostream>

#include "GameManager.h"

int main()
{

	CGameManager tGameManager;

	tGameManager.Play();

	return 0;
}