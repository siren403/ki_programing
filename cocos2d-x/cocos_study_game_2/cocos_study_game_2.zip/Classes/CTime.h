#ifndef __CTIME_H__
#define __CTIME_H__

#include "cocos2d.h"

using namespace cocos2d;

class CTime
{
public:
	static void setTimeScale(float tTimeScale);
	static float getTimeScale();
};

#endif // !__CTIME_H__
