#ifndef __B2TAG_H__
#define __B2TAG_H__

#define TAG_BULLET 1
#define TAG_BLOCK 2


#endif // !__B2TAG_H__
