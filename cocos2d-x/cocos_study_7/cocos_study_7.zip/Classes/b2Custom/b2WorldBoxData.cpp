#include "b2WorldBoxData.h"

WorldBoxTag b2WorldBoxData::GetTag()
{
	return mTag;
}
