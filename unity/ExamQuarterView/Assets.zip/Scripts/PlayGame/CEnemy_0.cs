﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CEnemy_0 : CMyEnemy
{

    private void Start()
    {
        StartAI();
    }

    
}
