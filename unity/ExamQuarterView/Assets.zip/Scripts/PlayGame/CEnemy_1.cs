﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CEnemy_1 : CMyEnemy
{

    private void Start()
    {
        StartAI();
    }

  
}
